(function($) {
    var foo = 2;
    $(function() {
        console.log('Hello World !');
    });
})(jQuery);
console.log(window.foo);
